
@echo off
title AuraDesk Guncelleniyor...
echo Lutfen bekleyin, yeni surum kuruluyor...
timeout /t 3 /nobreak > NUL
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path 'C:\Users\mmsuk\OneDrive\Desktop\Desktop_Organizer\bin\Debug\net10.0-windows\update_temp.zip' -DestinationPath 'C:\Users\mmsuk\OneDrive\Desktop\Desktop_Organizer\bin\Debug\net10.0-windows\' -Force"
del "C:\Users\mmsuk\OneDrive\Desktop\Desktop_Organizer\bin\Debug\net10.0-windows\update_temp.zip"
start "" "C:\Users\mmsuk\OneDrive\Desktop\Desktop_Organizer\bin\Debug\net10.0-windows\DesktopOrganizer.exe"
del "%~f0"
